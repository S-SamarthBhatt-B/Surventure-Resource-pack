# LifestealCore Fantasy 32x Resource Pack

Production-ready Java Edition resource pack for LifestealCore custom items.

## Version

- Selected Minecraft version: Java Edition 1.21.10
- Resource pack format: 69
- Compatibility range declared: 1.21.1 through 1.21.10 where supported by the client
- Item texture resolution: 32x32
- Style: medieval fantasy with crimson, black, gold, purple, and soul-fire blue accents

The prompt did not include a concrete Minecraft version, so this pack targets 1.21.10 and also includes legacy override files plus modern item-definition files. If your server is on a different client version, update `pack.mcmeta` using the guide in `docs/custom_model_data_map.json` and the notes below.

## Folder Tree

```text
.
|-- assets/
|   `-- minecraft/
|       |-- items/
|       |   |-- amethyst_shard.json
|       |   |-- barrier.json
|       |   |-- beacon.json
|       |   |-- clock.json
|       |   |-- command_block.json
|       |   |-- heart_of_the_sea.json
|       |   |-- nether_star.json
|       |   |-- paper.json
|       |   `-- totem_of_undying.json
|       |-- models/
|       |   `-- item/
|       |       |-- base vanilla override files
|       |       `-- custom item model files
|       `-- textures/
|           `-- item/
|               `-- 32x32 custom item PNG textures
|-- docs/
|   |-- custom_model_data_map.json
|   |-- item_manifest.md
|   |-- itemsadder-compat.yml
|   |-- lifestealcore-items-resourcepack-example.yml
|   |-- oraxen-compat.yml
|   `-- texture_preview.png
|-- pack.mcmeta
|-- pack.png
|-- tools/
|   `-- generate_pack.py
`-- LifestealCore-Fantasy-32x.zip
```

## How The JSON Works

Custom item models live in `assets/minecraft/models/item/<item_id>.json`. Each one uses `minecraft:item/generated` and points to its 32x32 texture in `assets/minecraft/textures/item/<item_id>.png`.

Legacy CustomModelData routing lives in `assets/minecraft/models/item/`amethyst_shard.json`, `barrier.json`, `beacon.json`, `clock.json`, `command_block.json`, `heart_of_the_sea.json`, `nether_star.json`, `paper.json`, `totem_of_undying.json``. These files preserve the vanilla fallback model or texture, then add exact `custom_model_data` predicates. Vanilla items without matching CustomModelData remain vanilla.

Modern routing for 1.21.4+ lives in `assets/minecraft/items/<vanilla_item>.json`. These files use `minecraft:range_dispatch` on `minecraft:custom_model_data`. Guard thresholds such as `2601.5` return to the vanilla fallback so unrelated CustomModelData values do not accidentally inherit a previous custom model.

The `clock` base item preserves the vanilla clock animation fallback and adds LifestealCore's default CMD values afterward.

## Item Manifest

| Item ID | Display Name | Material | CMD | Texture | Model | Notes |
|---|---|---:|---:|---|---|---|
| `heart` | Heart / Heart Tier I | `CLOCK` | `1` | `assets/minecraft/textures/item/heart.png` | `assets/minecraft/models/item/heart.json` | Matches LifestealCore default heart_tier1. |
| `extra_heart` | Extra Heart / Heart Tier II | `CLOCK` | `2` | `assets/minecraft/textures/item/extra_heart.png` | `assets/minecraft/models/item/extra_heart.json` | Matches LifestealCore default heart_tier2. |
| `legendary_heart` | Legendary Heart / Heart Tier III | `CLOCK` | `3` | `assets/minecraft/textures/item/legendary_heart.png` | `assets/minecraft/models/item/legendary_heart.json` | Matches LifestealCore default heart_tier3. |
| `scroll_escape` | Sacrificial Escape Scroll | `CLOCK` | `4` | `assets/minecraft/textures/item/scroll_escape.png` | `assets/minecraft/models/item/scroll_escape.json` | Matches LifestealCore default scroll_escape. |
| `scroll_revive` | Revive Scroll | `CLOCK` | `5` | `assets/minecraft/textures/item/scroll_revive.png` | `assets/minecraft/models/item/scroll_revive.json` | Reserved scroll slot between default IDs 4 and 6. |
| `scroll_shell` | Sacrificial Shell Scroll | `CLOCK` | `6` | `assets/minecraft/textures/item/scroll_shell.png` | `assets/minecraft/models/item/scroll_shell.json` | Matches LifestealCore default scroll_shell. |
| `scroll_rage` | Sacrificial Rage Scroll | `CLOCK` | `7` | `assets/minecraft/textures/item/scroll_rage.png` | `assets/minecraft/models/item/scroll_rage.json` | Matches LifestealCore default scroll_rage. |
| `rare_heart` | Rare Heart | `HEART_OF_THE_SEA` | `2101` | `assets/minecraft/textures/item/rare_heart.png` | `assets/minecraft/models/item/rare_heart.json` | Purple aura heart template for extra heart tiers. |
| `epic_heart` | Epic Heart | `HEART_OF_THE_SEA` | `2102` | `assets/minecraft/textures/item/epic_heart.png` | `assets/minecraft/models/item/epic_heart.json` | Soul fire heart template for extra heart tiers. |
| `heart_container` | Heart Container | `HEART_OF_THE_SEA` | `2103` | `assets/minecraft/textures/item/heart_container.png` | `assets/minecraft/models/item/heart_container.json` | Container item for max-heart upgrades or crates. |
| `revival_crystal` | Revival Crystal | `NETHER_STAR` | `2201` | `assets/minecraft/textures/item/revival_crystal.png` | `assets/minecraft/models/item/revival_crystal.json` | Crystal alternative to revive beacons. |
| `life_core` | Life Core | `NETHER_STAR` | `2202` | `assets/minecraft/textures/item/life_core.png` | `assets/minecraft/models/item/life_core.json` | High-value crafting core for custom recipes. |
| `heart_fragment` | Heart Fragment | `AMETHYST_SHARD` | `2301` | `assets/minecraft/textures/item/heart_fragment.png` | `assets/minecraft/models/item/heart_fragment.json` | Broken red crystal shard. |
| `heart_shard` | Heart Shard | `AMETHYST_SHARD` | `2302` | `assets/minecraft/textures/item/heart_shard.png` | `assets/minecraft/models/item/heart_shard.json` | Smaller crimson/gold shard. |
| `soul_fragment` | Soul Fragment | `AMETHYST_SHARD` | `2303` | `assets/minecraft/textures/item/soul_fragment.png` | `assets/minecraft/models/item/soul_fragment.json` | Floating blue spirit crystal. |
| `heart_voucher` | Heart Voucher | `PAPER` | `2401` | `assets/minecraft/textures/item/heart_voucher.png` | `assets/minecraft/models/item/heart_voucher.json` | Ancient magical voucher scroll. |
| `scroll_recall` | Recall Scroll | `PAPER` | `2402` | `assets/minecraft/textures/item/scroll_recall.png` | `assets/minecraft/models/item/scroll_recall.json` | Optional utility scroll template. |
| `scroll_sacrifice` | Sacrifice Scroll | `PAPER` | `2403` | `assets/minecraft/textures/item/scroll_sacrifice.png` | `assets/minecraft/models/item/scroll_sacrifice.json` | Generic sacrificial scroll template. |
| `totem_variant` | Lifesteal Totem Variant | `TOTEM_OF_UNDYING` | `2501` | `assets/minecraft/textures/item/totem_variant.png` | `assets/minecraft/models/item/totem_variant.json` | Custom totem-like Lifesteal item. |
| `revive_beacon` | Revive Beacon | `BEACON` | `2601` | `assets/minecraft/textures/item/revive_beacon.png` | `assets/minecraft/models/item/revive_beacon.json` | Resource-pack-ready Tier I beacon. |
| `revive_beacon_rare` | Revive Beacon Tier II | `BEACON` | `2602` | `assets/minecraft/textures/item/revive_beacon_rare.png` | `assets/minecraft/models/item/revive_beacon_rare.json` | Resource-pack-ready Tier II beacon. |
| `revive_beacon_epic` | Revive Beacon Tier III | `BEACON` | `2603` | `assets/minecraft/textures/item/revive_beacon_epic.png` | `assets/minecraft/models/item/revive_beacon_epic.json` | Resource-pack-ready Tier III beacon. |
| `revive_beacon_ghost` | Revive Beacon Ghost | `BEACON` | `2604` | `assets/minecraft/textures/item/revive_beacon_ghost.png` | `assets/minecraft/models/item/revive_beacon_ghost.json` | Silent/ghost revive beacon template. |
| `admin_heart` | Admin Heart | `COMMAND_BLOCK` | `9001` | `assets/minecraft/textures/item/admin_heart.png` | `assets/minecraft/models/item/admin_heart.json` | Obsidian admin-only heart item. |
| `admin_beacon` | Admin Beacon | `COMMAND_BLOCK` | `9002` | `assets/minecraft/textures/item/admin_beacon.png` | `assets/minecraft/models/item/admin_beacon.json` | Obsidian admin-only revive item. |
| `admin_eliminator` | Admin Eliminator | `BARRIER` | `9003` | `assets/minecraft/textures/item/admin_eliminator.png` | `assets/minecraft/models/item/admin_eliminator.json` | Dark admin elimination token. |
| `admin_reviver` | Admin Reviver | `BARRIER` | `9004` | `assets/minecraft/textures/item/admin_reviver.png` | `assets/minecraft/models/item/admin_reviver.json` | Dark admin revive token. |

## LifestealCore Installation

1. Upload `LifestealCore-Fantasy-32x.zip` somewhere directly downloadable, or place the folder/zip in your local `.minecraft/resourcepacks` folder for testing.
2. In `server.properties`, set `resource-pack=<direct zip URL>`.
3. Set `resource-pack-sha1=<sha1 of the zip>` if your server/client version still uses that field.
4. Restart Paper, Spigot, or Purpur.
5. In `plugins/LifestealCore/items.yml`, set each custom item material and `customModelData` to the values in `docs/custom_model_data_map.json`.
6. Run the LifestealCore reload command or restart the server, depending on your plugin version.

The Norska default hearts and scrolls already use `CLOCK` with CMD `1`, `2`, `3`, `4`, `6`, and `7`, so those work with the default `items.yml`. Default revive beacons use custom skull URLs with CMD `0`; to use this pack's beacon art, switch those beacon materials to `BEACON` and use CMD `2601` through `2604`.

## Adding New Items

1. Add a new `PackItem` entry in `tools/generate_pack.py`.
2. Pick a base material that your plugin item can safely use.
3. Pick a unique CustomModelData value. Keep ranges reserved by category.
4. Run `python tools/generate_pack.py`.
5. Update LifestealCore `items.yml` with the chosen material and CustomModelData.

Recommended ID ranges:

- `1-99`: LifestealCore default `CLOCK` items
- `2100-2199`: heart variants and containers
- `2200-2299`: crystals and cores
- `2300-2399`: fragments and shards
- `2400-2499`: vouchers and scrolls
- `2500-2599`: totem variants
- `2600-2699`: revive beacons
- `9000-9099`: admin-only items

## ItemsAdder Compatibility

Use this as an external/model-only pack and reserve the same CustomModelData IDs. See `docs/itemsadder-compat.yml` for starter entries. If ItemsAdder generates its own pack, merge this pack's `assets/minecraft` folder into the generated output and avoid reusing the same material/CMD pairs.

## Oraxen Compatibility

Use `generate_model: false` and point Oraxen entries at the existing model names. See `docs/oraxen-compat.yml`. If Oraxen is generating the pack, merge this pack after generation or copy these models/textures into Oraxen's pack source.

## Troubleshooting

- Purple/black item: the model path or texture path is wrong, or the PNG is missing.
- Vanilla item changed unexpectedly: check for another pack overriding the same base item model with higher priority.
- Custom item stays vanilla: verify the item material and `customModelData` in LifestealCore match `docs/custom_model_data_map.json`.
- Beacons still show skulls: stock LifestealCore beacons use custom skull materials. Switch to `BEACON` plus CMD `2601-2604`.
- Pack shows incompatible: update `pack.mcmeta` for your exact client version.
- Works in 1.21.1 but not newer: make sure the `assets/minecraft/items/*.json` files are included in the final zip.
- Works in newer versions but not 1.21.1: make sure the legacy `assets/minecraft/models/item/<base>.json` overrides are included.

## Pack Icon

`pack.png` is included. If replacing it, use a square PNG, keep the heart/core readable at small size, and avoid semi-transparent text because Minecraft scales this icon heavily.

## Regeneration

This pack is generated from `tools/generate_pack.py` so the models, modern item definitions, textures, docs, and zip stay synchronized. Re-run it after edits:

```powershell
python tools/generate_pack.py
```

# Item Manifest

Every custom texture is a 32x32 PNG in `assets/minecraft/textures/item/`.
Every custom item model is a generated item model in `assets/minecraft/models/item/`.

| Item ID | Display Name | Material | CMD | Texture | Model | Notes |
|---|---|---:|---:|---|---|---|
| `heart` | Heart / Heart Tier I | `CLOCK` | `1` | `assets/minecraft/textures/item/heart.png` | `assets/minecraft/models/item/heart.json` | Matches LifestealCore default heart_tier1. |
| `extra_heart` | Extra Heart / Heart Tier II | `CLOCK` | `2` | `assets/minecraft/textures/item/extra_heart.png` | `assets/minecraft/models/item/extra_heart.json` | Matches LifestealCore default heart_tier2. |
| `legendary_heart` | Legendary Heart / Heart Tier III | `CLOCK` | `3` | `assets/minecraft/textures/item/legendary_heart.png` | `assets/minecraft/models/item/legendary_heart.json` | Matches LifestealCore default heart_tier3. |
| `scroll_escape` | Sacrificial Escape Scroll | `CLOCK` | `4` | `assets/minecraft/textures/item/scroll_escape.png` | `assets/minecraft/models/item/scroll_escape.json` | Matches LifestealCore default scroll_escape. |
| `scroll_revive` | Revive Scroll | `CLOCK` | `5` | `assets/minecraft/textures/item/scroll_revive.png` | `assets/minecraft/models/item/scroll_revive.json` | Reserved scroll slot between default IDs 4 and 6. |
| `scroll_shell` | Sacrificial Shell Scroll | `CLOCK` | `6` | `assets/minecraft/textures/item/scroll_shell.png` | `assets/minecraft/models/item/scroll_shell.json` | Matches LifestealCore default scroll_shell. |
| `scroll_rage` | Sacrificial Rage Scroll | `CLOCK` | `7` | `assets/minecraft/textures/item/scroll_rage.png` | `assets/minecraft/models/item/scroll_rage.json` | Matches LifestealCore default scroll_rage. |
| `rare_heart` | Rare Heart | `HEART_OF_THE_SEA` | `2101` | `assets/minecraft/textures/item/rare_heart.png` | `assets/minecraft/models/item/rare_heart.json` | Purple aura heart template for extra heart tiers. |
| `epic_heart` | Epic Heart | `HEART_OF_THE_SEA` | `2102` | `assets/minecraft/textures/item/epic_heart.png` | `assets/minecraft/models/item/epic_heart.json` | Soul fire heart template for extra heart tiers. |
| `heart_container` | Heart Container | `HEART_OF_THE_SEA` | `2103` | `assets/minecraft/textures/item/heart_container.png` | `assets/minecraft/models/item/heart_container.json` | Container item for max-heart upgrades or crates. |
| `revival_crystal` | Revival Crystal | `NETHER_STAR` | `2201` | `assets/minecraft/textures/item/revival_crystal.png` | `assets/minecraft/models/item/revival_crystal.json` | Crystal alternative to revive beacons. |
| `life_core` | Life Core | `NETHER_STAR` | `2202` | `assets/minecraft/textures/item/life_core.png` | `assets/minecraft/models/item/life_core.json` | High-value crafting core for custom recipes. |
| `heart_fragment` | Heart Fragment | `AMETHYST_SHARD` | `2301` | `assets/minecraft/textures/item/heart_fragment.png` | `assets/minecraft/models/item/heart_fragment.json` | Broken red crystal shard. |
| `heart_shard` | Heart Shard | `AMETHYST_SHARD` | `2302` | `assets/minecraft/textures/item/heart_shard.png` | `assets/minecraft/models/item/heart_shard.json` | Smaller crimson/gold shard. |
| `soul_fragment` | Soul Fragment | `AMETHYST_SHARD` | `2303` | `assets/minecraft/textures/item/soul_fragment.png` | `assets/minecraft/models/item/soul_fragment.json` | Floating blue spirit crystal. |
| `heart_voucher` | Heart Voucher | `PAPER` | `2401` | `assets/minecraft/textures/item/heart_voucher.png` | `assets/minecraft/models/item/heart_voucher.json` | Ancient magical voucher scroll. |
| `scroll_recall` | Recall Scroll | `PAPER` | `2402` | `assets/minecraft/textures/item/scroll_recall.png` | `assets/minecraft/models/item/scroll_recall.json` | Optional utility scroll template. |
| `scroll_sacrifice` | Sacrifice Scroll | `PAPER` | `2403` | `assets/minecraft/textures/item/scroll_sacrifice.png` | `assets/minecraft/models/item/scroll_sacrifice.json` | Generic sacrificial scroll template. |
| `totem_variant` | Lifesteal Totem Variant | `TOTEM_OF_UNDYING` | `2501` | `assets/minecraft/textures/item/totem_variant.png` | `assets/minecraft/models/item/totem_variant.json` | Custom totem-like Lifesteal item. |
| `revive_beacon` | Revive Beacon | `BEACON` | `2601` | `assets/minecraft/textures/item/revive_beacon.png` | `assets/minecraft/models/item/revive_beacon.json` | Resource-pack-ready Tier I beacon. |
| `revive_beacon_rare` | Revive Beacon Tier II | `BEACON` | `2602` | `assets/minecraft/textures/item/revive_beacon_rare.png` | `assets/minecraft/models/item/revive_beacon_rare.json` | Resource-pack-ready Tier II beacon. |
| `revive_beacon_epic` | Revive Beacon Tier III | `BEACON` | `2603` | `assets/minecraft/textures/item/revive_beacon_epic.png` | `assets/minecraft/models/item/revive_beacon_epic.json` | Resource-pack-ready Tier III beacon. |
| `revive_beacon_ghost` | Revive Beacon Ghost | `BEACON` | `2604` | `assets/minecraft/textures/item/revive_beacon_ghost.png` | `assets/minecraft/models/item/revive_beacon_ghost.json` | Silent/ghost revive beacon template. |
| `admin_heart` | Admin Heart | `COMMAND_BLOCK` | `9001` | `assets/minecraft/textures/item/admin_heart.png` | `assets/minecraft/models/item/admin_heart.json` | Obsidian admin-only heart item. |
| `admin_beacon` | Admin Beacon | `COMMAND_BLOCK` | `9002` | `assets/minecraft/textures/item/admin_beacon.png` | `assets/minecraft/models/item/admin_beacon.json` | Obsidian admin-only revive item. |
| `admin_eliminator` | Admin Eliminator | `BARRIER` | `9003` | `assets/minecraft/textures/item/admin_eliminator.png` | `assets/minecraft/models/item/admin_eliminator.json` | Dark admin elimination token. |
| `admin_reviver` | Admin Reviver | `BARRIER` | `9004` | `assets/minecraft/textures/item/admin_reviver.png` | `assets/minecraft/models/item/admin_reviver.json` | Dark admin revive token. |

## Base Override Files

| File | Purpose |
|---|---|
| `assets/minecraft/models/item/clock.json` | Legacy default LifestealCore heart and scroll CMD overrides; preserves vanilla clock frames. |
| `assets/minecraft/models/item/heart_of_the_sea.json` | Legacy heart variant/container overrides. |
| `assets/minecraft/models/item/nether_star.json` | Legacy crystal/core overrides. |
| `assets/minecraft/models/item/amethyst_shard.json` | Legacy fragment/shard overrides. |
| `assets/minecraft/models/item/paper.json` | Legacy voucher/scroll overrides. |
| `assets/minecraft/models/item/totem_of_undying.json` | Legacy totem variant override. |
| `assets/minecraft/models/item/beacon.json` | Legacy revive beacon overrides; preserves vanilla beacon item model. |
| `assets/minecraft/models/item/command_block.json` | Legacy admin command-block item overrides. |
| `assets/minecraft/models/item/barrier.json` | Legacy admin barrier item overrides. |

## Modern Item Definition Files

The matching files in `assets/minecraft/items/` provide Minecraft 1.21.4+ item model definitions. They dispatch on numeric CustomModelData and fall back to vanilla models when the value is absent or outside a reserved exact slot.

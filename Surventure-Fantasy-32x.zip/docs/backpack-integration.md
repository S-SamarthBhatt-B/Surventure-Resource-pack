# Surventure Backpack Integration

## Texture

`assets/minecraft/textures/item/backpack.png`

- Resolution: 32x32
- Style target: Surventure/LifestealCore dark fantasy item art
- Palette: dark leather, crimson straps, bronze frame, gold buckles, purple crystal, soul-blue particles
- Readability pass: designed around a large central backpack silhouette with a bright enchanted crystal and small side potion

## Model

`assets/minecraft/models/item/backpack.json`

```json
{
  "parent": "minecraft:item/generated",
  "textures": {
    "layer0": "minecraft:item/backpack"
  }
}
```

## Eye Of Ender Override

Legacy override file:

`assets/minecraft/models/item/eye_of_ender.json`

```json
{
  "parent": "minecraft:item/generated",
  "textures": {
    "layer0": "minecraft:item/eye_of_ender"
  },
  "overrides": [
    {
      "predicate": {
        "custom_model_data": 2701
      },
      "model": "minecraft:item/backpack"
    }
  ]
}
```

Modern item definition file:

`assets/minecraft/items/eye_of_ender.json`

This uses `minecraft:range_dispatch` on `minecraft:custom_model_data`. CMD `2701` displays the backpack, then CMD `2701.5` returns to the vanilla fallback so unrelated Eye of Ender CMD values do not inherit this model.

## CustomModelData Example

Use material `EYE_OF_ENDER` and CustomModelData `2701`.

Example command:

```mcfunction
/give @p minecraft:eye_of_ender{CustomModelData:2701,display:{Name:'{"text":"Adventurer Backpack","color":"gold","italic":false}'}} 1
```

For Minecraft versions using item components, use the equivalent `minecraft:custom_model_data` component with value `2701`.

## LifestealCore / Plugin Config Example

```yaml
backpack:
  item:
    material: 'EYE_OF_ENDER'
    customModelData: 2701
    typeName: '<SOLID:f4be48>Adventurer Backpack'
```

## Installation

1. Keep `backpack.png` in `assets/minecraft/textures/item/`.
2. Keep `backpack.json` in `assets/minecraft/models/item/`.
3. Keep `eye_of_ender.json` in both `assets/minecraft/models/item/` and `assets/minecraft/items/`.
4. Zip the resource pack with `pack.mcmeta` at the zip root.
5. Give or configure an `EYE_OF_ENDER` item with CustomModelData `2701`.

## Surventure Notes

The backpack was added as a new item only. No existing LifestealCore heart, fragment, scroll, beacon, admin, or base override assets were edited.
